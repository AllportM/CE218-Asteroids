package Asteroids.utilities;

public class RotateableShapeException extends RuntimeException{
    public RotateableShapeException(String s)
    {
        super(s);
    }
}
