package Asteroids.utilities;

import Asteroids.game1.GameObject;
import Asteroids.game1.Ship;

import static Asteroids.game1.Constants.*;

public class ViewPort {
    private double x, y;
    Vector2D position;

    public ViewPort(Ship ps)
    {
        this.position = ps.position;
        this.x = position.x;
        this.y = position.y;
    }

    public void update()
    {
        double x =  position.x;
        double y =  position.y;
        this.x = (x > WORLD_WIDTH - FRAME_WIDTH/2)? -WORLD_WIDTH + FRAME_WIDTH:
                (x < FRAME_WIDTH/2)? 0: -x + FRAME_WIDTH / 2;
        this.y = (y > WORLD_HEIGHT - FRAME_HEIGHT/2)? -WORLD_HEIGHT + FRAME_HEIGHT:
                (y < FRAME_HEIGHT/2)? 0: -y  + FRAME_HEIGHT / 2;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }
}
