package Asteroids.game1;

import Asteroids.utilities.Action;

public interface Controller {
    Action action();
}
